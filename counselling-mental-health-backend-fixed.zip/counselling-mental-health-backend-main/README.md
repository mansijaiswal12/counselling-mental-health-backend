# Counselling Mental Health Backend

## Setup

1. Install Node.js (use the version specified in `.node-version`, if present).
2. Install dependencies:

   ```bash
   npm install
   ```

3. Create a local `.env` file by copying `.env.example`.
4. Set `MONGODB_URI` to your **newly rotated** MongoDB Atlas connection string. Do not commit `.env`.
5. Start the development server:

   ```bash
   npm run dev
   ```

The API starts on `http://localhost:8000` by default.

## Routes

- `GET /` — API health message
- `POST /contactus` — requires `name`, `mobileNo`, `email`, `date`, `time`
- `POST /feedback` — requires `name`, `comments`, `rating`; `therapyNames` is optional and should be an array

## Security

- `.env` and dependency folders are excluded by `.gitignore`.
- Never publish database credentials. Rotate any credential that was previously committed or shared.
- CORS is currently open to preserve the existing frontend integration. Restrict it to your deployed frontend origin before production.
