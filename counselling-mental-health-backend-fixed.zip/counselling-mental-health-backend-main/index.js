require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const ContactUsmodel = require("./model/contactForm");
const FeedbackModel = require("./model/feedbackForm");

const server = express();

server.use(cors());
server.use(express.json({ limit: "10kb" }));

server.get("/", (req, res) => {
  res.status(200).json({ message: "Counselling Mental Health API is running" });
});

// Contact Us form
server.post("/contactus", async (req, res) => {
  try {
    const { name, mobileNo, email, date, time } = req.body || {};

    if (!name || !mobileNo || !email || !date || !time) {
      return res.status(400).json({
        message: "name, mobileNo, email, date and time are required",
      });
    }

    const contactdata = await ContactUsmodel.create({
      name,
      mobileNo,
      email,
      date,
      time,
    });

    return res.status(201).json(contactdata);
  } catch (error) {
    console.error("Contact form error:", error.message);
    return res.status(500).json({ message: "Unable to submit contact form" });
  }
});

// Feedback form
server.post("/feedback", async (req, res) => {
  try {
    const { name, comments, rating, therapyNames } = req.body || {};

    if (!name || !comments || rating === undefined || rating === null) {
      return res.status(400).json({
        message: "name, comments and rating are required",
      });
    }

    const feedbackData = await FeedbackModel.create({
      name,
      comments,
      rating,
      therapyNames: Array.isArray(therapyNames) ? therapyNames : [],
    });

    return res.status(201).json(feedbackData);
  } catch (error) {
    console.error("Feedback form error:", error.message);
    return res.status(500).json({ message: "Unable to submit feedback" });
  }
});

const PORT = process.env.PORT || 8000;

async function startServer() {
  if (!process.env.MONGODB_URI) {
    console.error("Startup failed: MONGODB_URI is not configured.");
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("MongoDB connected successfully");

    server.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("MongoDB connection failed:", error.message);
    process.exit(1);
  }
}

startServer();

process.on("SIGINT", async () => {
  await mongoose.disconnect();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  await mongoose.disconnect();
  process.exit(0);
});
